module.exports=[
    {
        typeId:6,
        productID:1,
        productName:'单衬衫',
        price:15,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000\n' +
        '&sec=1513004037558&di=26102af747d79ac1c226d11448349c9d&imgtype=\n' +
        '0&src=http%3A%2F%2Fimages.xiu.com%2Fupload%2Fgoods20160218%2F10429009%2Fe3.jpg'
    },
    {
        typeId:6,
        productID:2,
        productName:'保暖衬衫',
        price:25,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=15130040914\n' +
        '49&di=f3fb706e9421c1190c5eb32968912000&imgtype=0&src=http%3A%2F%2Fm.360buyimg.com\n' +
        '%2Fn12%2Fg13%2FM01%2F13%2F13%2FrBEhUlLw4fUIAAAAAAL5V7tqgioAAIS0gOFsvoAAvlv669.jpg%2521q70.jpg'
    },
    {
        typeId:6,
        productID:3,
        productName:'真丝衬衫',
        price:39,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004149695&di=d85e79adff8cf995cbff5d6550694b6f&imgtype=0&src=http%3A%2F%2Fimg14.360buyimg.com%2FpopWaterMark%2Fjfs%2Ft1492%2F226%2F61027325%2F94040%2F41d37599%2F5552fa26Nf029e887.jpg'
    },
    {
        typeId:6,
        productID:4,
        productName:'T恤/polo衫',
        price:15,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004204627&di=848879da48672992fa3e8dd253e5a392&imgtype=0&src=http%3A%2F%2Fwww.36588.com.cn%3A8080%2FImageResourceMongo%2FUploadedFile%2Fdimension%2Fbig%2Fe6e8cd6f-2150-4532-b204-7ffcb8813845.png'
    },
    {
        typeId:6,
        productID:5,
        productName:'西服上衣',
        price:25,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513003915040&di=dc679925dc08f85fb047393c95ef6dba&imgtype=0&src=http%3A%2F%2Fpic11.shangpin.com%2Ff%2Fp%2F14%2F02%2F24%2F20140224180640745459-492-600.jpg'
    },
    {
        typeId:6,
        productID:6,
        productName:'卫衣',
        price:25,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004314067&di=4efc7ea9ff3658fdbd51ade3e0c557e0&imgtype=0&src=http%3A%2F%2Fimg011.hc360.cn%2Fg1%2FM07%2F56%2F47%2FwKhQMFMhjb6EFIC2AAAAAHeXOxE770.jpg'
    },
    {
        typeId:6,
        productID:7,
        productName:'夹克',
        price:25,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004364966&di=a5927ba333cc6fbf8b2d044ba9b6433c&imgtype=0&src=http%3A%2F%2Fimgm.ph.126.net%2Fq2NMPjR7rI1yCJ1nhO-ZUw%3D%3D%2F1042020363801038549.jpg'
    },
    {
        typeId:6,
        productID:8,
        productName:'真丝上衣',
        price:39,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004410657&di=1e718c0f55fd1fdf6abe1609a94633f9&imgtype=0&src=http%3A%2F%2Fimgqn.koudaitong.com%2Fupload_files%2F2015%2F03%2F28%2FFhFYYk61Ta3xMkUbYvdXkTiDYgNR.PNG%2521580x580.jpg'
    },
    {
        typeId:6,
        productID:9,
        productName:'背心',
        price:15,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004478148&di=97b75e09bf37ca09603312a78ebac017&imgtype=0&src=http%3A%2F%2Fwww.bailihua.com%2Fimages%2Fup_images%2F20140711230348819.JPG'
    },
    {
        typeId:6,
        productID:10,
        productName:'pu类上衣',
        price:69,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004556117&di=1b69e86fdea9dd447880a7debfd74c9b&imgtype=0&src=http%3A%2F%2Fimg4.tbcdn.cn%2Ftfscom%2Fi6%2FTB1wcOHXe7JL1JjSZFKYXI4KXXa_M2.SS2'
    },
    {
        typeId:6,
        productID:11,
        productName:'唐装',
        price:49,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513599149&di=8695c48e8fa698d1f1e2d4f21f98379b&imgtype=jpg&er=1&src=http%3A%2F%2Fimage.cn.made-in-china.com%2F2f0j01WeEavhVRVUqH%2F%25E7%25BB%25A3%25E9%25BE%2599%25E5%2594%2590%25E8%25A3%2585.jpg'
    },
    {
        typeId:6,
        productID:12,
        productName:'毛背心(马甲)',
        price:25,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513599191&di=48ea5b58b5925f4205484cd5d99000cc&imgtype=jpg&er=1&src=http%3A%2F%2Fimages.shopin.net%2Fimages%2F1004%2F2014%2F12%2F05%2FPic9576691_1992265_0.jpg'
    },
    {
        typeId:6,
        productID:13,
        productName:'毛衣',
        price:29,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004703576&di=b58e846a11fb3796ce074cc621308cf1&imgtype=0&src=http%3A%2F%2Fb.hiphotos.baidu.com%2Fzhidao%2Fpic%2Fitem%2F5fdf8db1cb13495400b04a27564e9258d0094ac2.jpg'
    },
    {
        typeId:6,
        productID:14,
        productName:'保暖衣',
        price:29,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004857599&di=daaa38a9ffc384c7d8f15e50d2bfef40&imgtype=0&src=http%3A%2F%2Ffile2.youboy.com%2Fe%2F2014%2F11%2F8%2F36%2F814538.JPG'
    },
    {
        typeId:6,
        productID:15,
        productName:'单睡衣',
        price:15,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004894950&di=333e80f14102d379b96b4165f8be7e6e&imgtype=0&src=http%3A%2F%2Fimg.mp.sohu.com%2Fupload%2F20170512%2Fd99f3a99ea294dd5812ae41b72842ae7_th.png'
    },
    {
        typeId:6,
        productID:16,
        productName:'棉睡衣',
        price:29,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513004922794&di=c3bfa03e77f30bfa988cb6de03a122df&imgtype=0&src=http%3A%2F%2Fimage.11467.com%2F84%2F11%2F84111517176770.jpg'
    },
    {
        typeId:7,
        productID:17,
        productName:'棉/羽绒背心(马甲)',
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:7,
        productID:18,
        productName:'风衣',
        price:49,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:7,
        productID:19,
        productName:'羊毛/绒外套',
        price:49,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:7,
        productID:20,
        productName:'棉服',
        price:49,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:7,
        productID:21,
        productName:'羽绒服',
        price:49,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:7,
        productID:22,
        productName:'冲锋衣(无内胆)',
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:7,
        productID:23,
        productName:'冲锋衣(含内胆)',
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:7,
        productID:24,
        productName:'pu类大衣' ,
        price:89,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:25,
        productName:'普通半身裙' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:26,
        productName:'普通连衣裙' ,
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:27,
        productName:'毛呢半身裙' ,
        price:25,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:28,
        productName:'毛呢连衣裙' ,
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:29,
        productName:'pu类半身裙' ,
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:30,
        productName:'pu类连衣裙' ,
        price:69,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:31,
        productName:'真丝半身裙' ,
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:32,
        productName:'旗袍' ,
        price:59,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:33,
        productName:'西裤' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:34,
        productName:'短裤' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:35,
        productName:'牛仔裤' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:36,
        productName:'休闲裤' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:37,
        productName:'真丝连衣裙' ,
        price:49,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:38,
        productName:'连体裤' ,
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:39,
        productName:'真丝裤' ,
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:40,
        productName:'毛裤' ,
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:41,
        productName:'棉裤/羽绒裤' ,
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:42,
        productName:'pu类裤子' ,
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:43,
        productName:'保暖裤' ,
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:44,
        productName:'单睡裤' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:45,
        productName:'棉睡裤' ,
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:46,
        productName:'睡袍' ,
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:8,
        productID:47,
        productName:'普通睡裙' ,
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    } ,
    {
        typeId:9,
        productID:48,
        productName:'领带' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    } ,
    {
        typeId:9,
        productID:49,
        productName:'帽子' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:9,
        productID:50,
        productName:'围巾' ,
        price:25,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:9,
        productID:51,
        productName:'丝巾' ,
        price:25,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:9,
        productID:52,
        productName:'披肩' ,
        price:25,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:9,
        productID:53,
        productName:'毛领' ,
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:10,
        productID:54,
        productName:'运动鞋' ,
        price:29,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513005528151&di=b9549da3765568f76c07ea2684f36294&imgtype=0&src=http%3A%2F%2Fotherimg.s.cn%2Fuploads%2Fallimg%2F160428%2F1520-16042Q12059125.jpg'
    },
    {
        typeId:10,
        productID:55,
        productName:'帆布鞋' ,
        price:29,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513006061802&di=240ae6fd5260ce50a829cbc34297bd41&imgtype=0&src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F0140d05550594a000000592c065ebe.jpg'
    },
    {
        typeId:10,
        productID:56,
        productName:'皮鞋' ,
        price:29,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513006125091&di=eee16618fc1c867c611d341d95a557e8&imgtype=0&src=http%3A%2F%2Fimg13.360buyimg.com%2FpopWaterMark%2Fg14%2FM00%2F0A%2F1B%2FrBEhVlIMix8IAAAAAAOWn1DE3HIAACH3gIZbnYAA5a3696.jpg'
    },
    {
        typeId:10,
        productID:57,
        productName:'棉鞋' ,
        price:49,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513006357577&di=28b97fcda0235e20406053e81c1eab6e&imgtype=0&src=http%3A%2F%2Fimg004.hc360.cn%2Fhb%2FMTQ2MjIzNjgwNTE3Ni0xNzc5MDA0OTEx.jpg'
    },
    {
        typeId:10,
        productID:58,
        productName:'布鞋' ,
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:10,
        productID:59,
        productName:'拖鞋' ,
        price:29,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513006484665&di=72cfae3e34499e307cac298db09092f6&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fimgad%2Fpic%2Fitem%2Fc995d143ad4bd113af95840851afa40f4bfb05ab.jpg'
    },
    {
        typeId:10,
        productID:60,
        productName:'凉鞋' ,
        price:29,
        img:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1513006445064&di=54046702fdf84fecce1205621edf962e&imgtype=0&src=http%3A%2F%2Fimg005.hc360.cn%2Fm7%2FM00%2FDF%2FBA%2FwKhQo1VdU9qEQ9zlAAAAAErea44519.jpg'
    },
    {
        typeId:11,
        productID:61,
        productName:'短款雪地靴' ,
        price:79,
        img:'https://img.alicdn.com/imgextra/i4/1099103722/TB2lJ6afqagSKJjy0FgXXcRqFXa_!!1099103722.jpg_430x430q90.jpg'
    },
    {
        typeId:11,
        productID:62,
        productName:'中款雪地靴' ,
        price:89,
        img:'https://img.alicdn.com/imgextra/i4/1099103722/TB2lJ6afqagSKJjy0FgXXcRqFXa_!!1099103722.jpg_430x430q90.jpg'
    },
    {
        typeId:11,
        productID:63,
        productName:'长款雪地靴' ,
        price:89,
        img:'https://img.alicdn.com/imgextra/i4/1099103722/TB2lJ6afqagSKJjy0FgXXcRqFXa_!!1099103722.jpg_430x430q90.jpg'
    },
    {
        typeId:11,
        productID:64,
        productName:'短款绒面靴' ,
        price:79,
        img:'https://img.alicdn.com/imgextra/i4/1099103722/TB2lJ6afqagSKJjy0FgXXcRqFXa_!!1099103722.jpg_430x430q90.jpg'
    },
    {
        typeId:11,
        productID:65,
        productName:'中款绒面靴' ,
        price:89,
        img:'https://img.alicdn.com/imgextra/i4/1099103722/TB2lJ6afqagSKJjy0FgXXcRqFXa_!!1099103722.jpg_430x430q90.jpg'
    },
    {
        typeId:11,
        productID:66,
        productName:'长款绒面靴' ,
        price:89,
        img:'https://img.alicdn.com/imgextra/i4/1099103722/TB2lJ6afqagSKJjy0FgXXcRqFXa_!!1099103722.jpg_430x430q90.jpg'
    },
    {
        typeId:11,
        productID:67,
        productName:'短款非绒面靴' ,
        price:49,
        img:'https://img.alicdn.com/imgextra/i4/1099103722/TB2lJ6afqagSKJjy0FgXXcRqFXa_!!1099103722.jpg_430x430q90.jpg'
    },
    {
        typeId:11,
        productID:68,
        productName:'中款非绒面靴' ,
        price:59,
        img:'https://img.alicdn.com/imgextra/i4/1099103722/TB2lJ6afqagSKJjy0FgXXcRqFXa_!!1099103722.jpg_430x430q90.jpg'
    },
    {
        typeId:11,
        productID:69,
        productName:'长款非绒面靴' ,
        price:59,
        img:'https://img.alicdn.com/imgextra/i4/1099103722/TB2lJ6afqagSKJjy0FgXXcRqFXa_!!1099103722.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:70,
        productName:'枕巾' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:71,
        productName:'枕套' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:72,
        productName:'床单' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:73,
        productName:'被罩' ,
        price:29,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:74,
        productName:'床罩' ,
        price:79,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:75,
        productName:'被褥' ,
        price:79,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:76,
        productName:'毛巾' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:77,
        productName:'浴巾' ,
        price:25,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:78,
        productName:'毛巾被' ,
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:79,
        productName:'踏花被' ,
        price:75,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:80,
        productName:'毛毯' ,
        price:25,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:81,
        productName:'蚕丝被' ,
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:82,
        productName:'羽绒被' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:83,
        productName:'包' ,
        price:25,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:84,
        productName:'汽车坐垫' ,
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:85,
        productName:'靠垫' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:86,
        productName:'沙发套(蓝洗带)' ,
        price:299,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:87,
        productName:'沙发套(白洗带)' ,
        price:158,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:88,
        productName:'真丝被罩' ,
        price:15,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:89,
        productName:'真丝床单' ,
        price:25,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:3,
        productID:90,
        productName:'真丝枕套' ,
        price:39,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:4,
        productID:91,
        productName:'e袋洗' ,
        price:299,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:4,
        productID:92,
        productName:'窗帘拆装费' ,
        price:100,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:5,
        productID:93,
        productName:'e袋洗（白袋）' ,
        price:158,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    },
    {
        typeId:5,
        productID:94,
        productName:'e袋洗（蓝袋）' ,
        price:100,
        img:'https://img.alicdn.com/bao/uploaded/i3/398509203/TB1BJ8mhdrJ8KJjSspaXXXuKpXa_!!0-item_pic.jpg_430x430q90.jpg'
    }
]